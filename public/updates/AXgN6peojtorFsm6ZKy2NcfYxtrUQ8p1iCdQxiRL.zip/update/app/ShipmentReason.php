<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShipmentReason extends Model
{
    //
}
