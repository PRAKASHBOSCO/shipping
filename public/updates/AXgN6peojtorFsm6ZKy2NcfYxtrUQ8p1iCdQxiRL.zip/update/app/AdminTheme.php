<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminTheme extends Model
{
    //
}
